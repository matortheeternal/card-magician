import computeAutoWatermark from './computeAutoWatermark.js';

const L = localize('module-M15-watermark');

const guildOptions = [
    { id: 'wu', name: L`Azorius` },
    { id: 'wr', name: L`Boros` },
    { id: 'ub', name: L`Dimir` },
    { id: 'ur', name: L`Izzet` },
    { id: 'bg', name: L`Golgari` },
    { id: 'rg', name: L`Gruul` },
    { id: 'wb', name: L`Orzhov ` },
    { id: 'br', name: L`Rakdos` },
    { id: 'wg', name: L`Selesnya` },
    { id: 'ug', name: L`Simic` },
];

const separator = () => ({ separator: true });

const watermark = (id, name, imagePath, extra) => ({
    id,
    name: name || id.normalizeWords().toTitleCase(),
    ...(id.includes('autodetect') ? {} : { imagePath: imagePath || `${id}.png`}),
    ...(extra ? extra.except('id', 'name', 'imagePath') : {})
});

const watermarkGroup = (groupId, items) => ({
    id: groupId,
    name: L([groupId.normalizeWords().toTitleCase()]),
    items
});

const watermarkGuildGroup = (groupId) => watermarkGroup(
    groupId,
    guildOptions.map(opt => watermark(
        `${groupId}/${opt.id}`,
        opt.name
    ))
);

const autodetectOption = (compute) => ({
    id: 'autodetect',
    name: 'Auto',
    compute
});

export default () => ([
    autodetectOption(computeAutoWatermark),
    separator(),
    watermarkGroup('mana', [
        watermark('mana/w', L`White`),
        watermark('mana/u', L`Blue`),
        watermark('mana/b', L`Black`),
        watermark('mana/r', L`Red`),
        watermark('mana/g', L`Green`),
        watermark('mana/c', L`Colorless`),
    ]),
    separator(),
    watermarkGuildGroup('mana-pair'),
    watermarkGuildGroup('ravnica'),
    watermarkGuildGroup('og-ravnica'),
]);
