import makeWatermarkOptions from './src/watermarkOptions.js';
import { resolveOption } from '../FaceSymbol/src/helpers.js';

const L = localize('module-M15-watermark');

export default class WatermarkModule extends CardMagicianModule {
    loadImage(opt) {
        opt.imageUrl = this.resolveAsset(opt.imagePath);
    }

    loadWatermarkImages(options) {
        options.concat(options.flatMap(opt => opt.items || []))
            .filter(opt => Boolean(opt.imagePath))
            .map(opt => this.loadImage(opt));
    }

    async init(card) {
        this.watermarkField = {
            id: 'watermark',
            type: 'nested-menu',
            label: L`Watermark`,
            options: makeWatermarkOptions(),
            default: null
        };
        this.loadWatermarkImages(this.watermarkField.options);
    }

    updateWatermark(card) {
        const options = this.watermarkField.options;
        const option = resolveOption(options, card.watermark);
        card.resolvedWatermark = option?.compute
            ? option.compute(card, options)
            : option;
        this.requestRender();
    }

    bind(card, watch) {
        watch(card, ['watermark', 'colorIdentity'], () => this.updateWatermark(card));
    }

    render(card) {
        if (!card.resolvedWatermark?.imageUrl) return;
        return (
            `<img src="${card.resolvedWatermark.imageUrl}" />`
        );
    }

    get fields() {
        return [this.watermarkField];
    }

    async styles() {
        return [await this.loadFile('style.css')];
    }
}
