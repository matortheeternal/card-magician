import Alpine from 'alpinejs';
import { saveJson, saveYAML } from '../../services/fsHelpers.js';
import { executeAction } from '../../services/actionRegistry.js';
import { registerHotkey } from '../../services/hotkeyService.js';
import { addStatusMessage } from '../../services/statusService.js';

function menuItem(label, hotkey, action) {
    if (hotkey !== '') registerHotkey(hotkey, action);
    return { label, value: label.toCamelCase(), hotkey, action };
}

const DIVIDER = { isDivider: true };

const saveStrategies = [{
    test: filePath => /.json$/i.test(filePath),
    save: async (filePath, data) => await saveJson(filePath, data, false)
}, {
    test: filePath => /.yml$/i.test(filePath),
    save: async (filePath, data) => await saveYAML(filePath, data)
}];

async function save(filePath, data) {
    const saveStrategy = saveStrategies.find(s => {
        return s.test(filePath);
    }) || saveStrategies[0];
    await saveStrategy.save(filePath, data);
}

async function saveAs() {
    const views = Alpine.store('views');
    const defaultPath = views.setFilePath
        ?  views.setFilePath.split(/[\\\/]/).pop()
        : `${views.activeSet.title || 'My Set'}.json`;
    const filePath = await Neutralino.os.showSaveDialog('Save set to file', {
        defaultPath,
        filters: [
            { name: 'JSON Files', extensions: ['json'] },
            { name: 'YAML Files', extensions: ['yml'] },
            { name: 'All files', extensions: ['*'] }
        ]
    });
    if (!filePath) return;
    console.info('Saving set to:', filePath);
    views.setFilePath = filePath;
    await save(filePath, views.activeSet);
}

const actions = {
    makeNewSet: () => executeAction('new-set'),
    openSet: () => executeAction('open-set'),
    save: async () => {
        const { activeSet, setFilePath } = Alpine.store('views');
        if (!setFilePath) return await saveAs();
        const message = addStatusMessage('Saving...', -1);
        console.info('Saving set to:', setFilePath);
        await save(setFilePath, activeSet);
        message.text = 'Saved.';
        setTimeout(() => message.remove(), 1000);
    },
    saveAs: saveAs,
    exportAs: () => executeAction('export-card-image'),
    print: () => console.log('Print'),
    exit: () => Neutralino.app.exit(0),
    undo: () => console.log('Undo'),
    redo: () => console.log('Redo'),
    cut: () => executeAction('cut'),
    copy: () => executeAction('copy'),
    paste: () => executeAction('paste'),
    editPreferences: () => console.log('Edit preferences'),
    editSetInfo: () => (Alpine.store('views').activeModal = 'set-info'),
    addCard: () => executeAction('add-card'),
    deleteCards: () => executeAction('delete-selected-cards'),
};

export const titleBarMenus = [{
    title: 'File',
    items: [
        menuItem('New', 'Ctrl+N', actions.makeNewSet),
        menuItem('Open', 'Ctrl+O', actions.openSet),
        menuItem('Save', 'Ctrl+S', actions.save),
        menuItem('Save as', 'Ctrl+Shift+S', actions.saveAs),
        menuItem('Export', 'Ctrl+Shift+E', actions.exportAs),
        DIVIDER,
        menuItem('Print', 'Ctrl+P', actions.print),
        DIVIDER,
        menuItem('Exit', '', actions.exit),
    ]
}, {
    title: 'Edit',
    items: [
        menuItem('Undo', 'Ctrl+Z', actions.undo),
        menuItem('Redo', 'Ctrl+Shift+Z', actions.redo),
        DIVIDER,
        menuItem('Cut', 'Ctrl+X', actions.cut),
        menuItem('Copy', 'Ctrl+C', actions.copy),
        menuItem('Paste', 'Ctrl+V', actions.paste),
        DIVIDER,
        menuItem('Set Info', '', actions.editSetInfo),
        menuItem('Preferences', '', actions.editPreferences),
    ]
}, {
    title: 'Cards',
    items: [
        menuItem('Add Card', 'Ctrl+Enter', actions.addCard),
        menuItem('Delete Cards', 'Delete', actions.deleteCards),
    ]
}];

